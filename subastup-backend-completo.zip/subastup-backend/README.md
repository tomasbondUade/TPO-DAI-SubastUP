# SubastUp — Backend

API REST en Express + TypeScript + Prisma + MySQL.

## Instalación

```bash
npm install
```

## Configuración

```bash
cp .env.example .env
# Editá .env con tus datos de MySQL y Gmail
```

## Base de datos

```bash
npm run db:migrate
```

## Correr el servidor

```bash
npm run dev
```

## Endpoints completos

### AUTH
| Método | Ruta | Descripción |
|--------|------|-------------|
| POST | /auth/register/step1 | Registro paso 1 (datos personales) |
| POST | /auth/register/step2 | Registro paso 2 (dirección y foto) |
| POST | /auth/login | Iniciar sesión → devuelve JWT |
| POST | /auth/forgot-password | Envía código por email |
| POST | /auth/verify-code | Valida el código |
| POST | /auth/reset-password | Cambia la contraseña |

### SUBASTAS (Home)
| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | /auctions | Home: subastas especiales y comunes |
| GET | /auctions/:id | Detalle de una subasta |

### PRODUCTOS (Cargar bien)
| Método | Ruta | Descripción |
|--------|------|-------------|
| POST | /products/step1 | Paso 1: detalles del lote |
| POST | /products/step2/:productId | Paso 2: subir imágenes (máx 4) |
| GET | /products/user/:userId | Mis productos |

### AYUDA
| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | /help | FAQs + info de soporte |

## Subida de imágenes

El endpoint `POST /products/step2/:productId` acepta `multipart/form-data` con el campo `images[]` (máx 4 archivos, 5MB c/u). Las imágenes se guardan en `uploads/products/` y se sirven en `/uploads/products/archivo.jpg`.

## Estructura

```
src/
├── index.ts
├── controllers/
│   ├── authController.ts
│   ├── auctionController.ts
│   ├── productController.ts
│   └── helpController.ts
├── routes/
│   ├── auth.ts
│   ├── auctions.ts
│   ├── products.ts
│   └── help.ts
├── middlewares/
│   ├── authMiddleware.ts
│   └── uploadMiddleware.ts
└── lib/
    └── prisma.ts
prisma/
└── schema.prisma
```
