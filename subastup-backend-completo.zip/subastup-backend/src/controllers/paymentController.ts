import { Request, Response } from 'express';
import prisma from '../lib/prisma';
import path from 'path';
import fs from 'fs';

// ─────────────────────────────────────────────
// GET /payments/:userId
// Lista todos los métodos de pago de un usuario
// ─────────────────────────────────────────────
export const getPaymentMethods = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId } = req.params;

    const methods = await prisma.paymentMethod.findMany({
      where: { userId: Number(userId) },
      orderBy: { createdAt: 'asc' },
    });

    res.json(methods);
  } catch (error) {
    console.error('getPaymentMethods error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// POST /payments/card
// Agrega método de pago: Tarjeta
// Body: { userId, holderName, cardNumber, expiryMonth, expiryYear, cvv,
//         address, zipCode, country, city }
// ─────────────────────────────────────────────
export const addCardPayment = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      userId, holderName, cardNumber, expiryMonth,
      expiryYear, cvv, address, zipCode, country, city,
    } = req.body;

    if (!userId || !holderName || !cardNumber || !expiryMonth || !expiryYear || !cvv || !address || !zipCode || !country || !city) {
      res.status(400).json({ message: 'Todos los campos de la tarjeta son requeridos.' });
      return;
    }

    // Validaciones básicas
    if (cardNumber.replace(/\s/g, '').length !== 16) {
      res.status(400).json({ message: 'El número de tarjeta debe tener 16 dígitos.' });
      return;
    }

    if (cvv.length < 3 || cvv.length > 4) {
      res.status(400).json({ message: 'El código de seguridad debe tener 3 o 4 dígitos.' });
      return;
    }

    const user = await prisma.user.findUnique({ where: { id: Number(userId) } });
    if (!user) {
      res.status(404).json({ message: 'Usuario no encontrado.' });
      return;
    }

    // Guardamos solo los últimos 4 dígitos por seguridad
    const lastFour = cardNumber.replace(/\s/g, '').slice(-4);

    const method = await prisma.paymentMethod.create({
      data: {
        userId: Number(userId),
        type: 'CARD',
        label: `Tarjeta terminada en ${lastFour}`,
        holderName,
        cardLastFour: lastFour,
        expiryMonth: String(expiryMonth),
        expiryYear: String(expiryYear),
        address,
        zipCode,
        country,
        city,
      },
    });

    res.status(201).json({
      message: 'Datos guardados correctamente.',
      paymentMethod: method,
    });
  } catch (error) {
    console.error('addCardPayment error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// POST /payments/bank
// Agrega método de pago: Transferencia bancaria (CBU)
// Body: { userId, cbu, alias, holderName }
// ─────────────────────────────────────────────
export const addBankPayment = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId, cbu, alias, holderName } = req.body;

    if (!userId || !cbu || !holderName) {
      res.status(400).json({ message: 'userId, CBU y nombre del titular son requeridos.' });
      return;
    }

    if (cbu.length !== 22) {
      res.status(400).json({ message: 'El CBU debe tener 22 dígitos.' });
      return;
    }

    const user = await prisma.user.findUnique({ where: { id: Number(userId) } });
    if (!user) {
      res.status(404).json({ message: 'Usuario no encontrado.' });
      return;
    }

    const method = await prisma.paymentMethod.create({
      data: {
        userId: Number(userId),
        type: 'BANK',
        label: `CBU ${cbu.slice(-4)}`,
        holderName,
        cbu,
        alias: alias || null,
      },
    });

    res.status(201).json({
      message: 'Datos guardados correctamente.',
      paymentMethod: method,
    });
  } catch (error) {
    console.error('addBankPayment error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// POST /payments/check
// Agrega método de pago: Cheque
// Multipart form-data: { userId, bankName, branchNumber, checkNumber,
//                        paymentDay, paymentMonth, paymentYear } + image
// ─────────────────────────────────────────────
export const addCheckPayment = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      userId, bankName, branchNumber,
      checkNumber, paymentDay, paymentMonth, paymentYear,
    } = req.body;

    if (!userId || !bankName || !branchNumber || !checkNumber || !paymentDay || !paymentMonth || !paymentYear) {
      res.status(400).json({ message: 'Todos los campos del cheque son requeridos.' });
      return;
    }

    const user = await prisma.user.findUnique({ where: { id: Number(userId) } });
    if (!user) {
      res.status(404).json({ message: 'Usuario no encontrado.' });
      return;
    }

    const file = req.file as Express.Multer.File | undefined;
    const checkImageUrl = file ? `/uploads/checks/${file.filename}` : null;

    const method = await prisma.paymentMethod.create({
      data: {
        userId: Number(userId),
        type: 'CHECK',
        label: `Cheque N° ${checkNumber}`,
        bankName,
        branchNumber,
        checkNumber,
        paymentDay: String(paymentDay),
        paymentMonth: String(paymentMonth),
        paymentYear: String(paymentYear),
        checkImageUrl,
      },
    });

    res.status(201).json({
      message: 'Datos guardados correctamente.',
      paymentMethod: method,
    });
  } catch (error) {
    console.error('addCheckPayment error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// DELETE /payments/:id
// Elimina un método de pago
// ─────────────────────────────────────────────
export const deletePaymentMethod = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;

    const method = await prisma.paymentMethod.findUnique({ where: { id: Number(id) } });
    if (!method) {
      res.status(404).json({ message: 'Método de pago no encontrado.' });
      return;
    }

    // Si tiene imagen de cheque, la borramos del disco
    if (method.checkImageUrl) {
      const filePath = path.join(process.cwd(), method.checkImageUrl);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }

    await prisma.paymentMethod.delete({ where: { id: Number(id) } });

    res.json({ message: 'Método de pago eliminado.' });
  } catch (error) {
    console.error('deletePaymentMethod error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};
