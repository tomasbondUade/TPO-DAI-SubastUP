import { Request, Response } from 'express';
import prisma from '../lib/prisma';

// ─────────────────────────────────────────────
// GET /help
// Devuelve FAQs y datos de soporte
// ─────────────────────────────────────────────
export const getHelp = async (_req: Request, res: Response): Promise<void> => {
  try {
    const faqs = await prisma.fAQ.findMany({
      where: { active: true },
      orderBy: { order: 'asc' },
    });

    res.json({
      faqs,
      support: {
        email: 'soporteSubastUp@gmail.com',
        description:
          'Reporta un problema con un artículo, solicita ayuda con una transacción o contacta directamente con nuestro equipo de soporte técnico 24/7.',
      },
    });
  } catch (error) {
    console.error('getHelp error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};
