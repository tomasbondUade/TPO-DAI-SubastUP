import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import prisma from '../lib/prisma';
import { sendResetCodeEmail } from '../services/emailService';

const generateCode = (): string =>
  Math.floor(100000 + Math.random() * 900000).toString();

const generateToken = (userId: number): string =>
  jwt.sign({ userId }, process.env.JWT_SECRET as string, { expiresIn: '7d' });

// ─────────────────────────────────────────────
// POST /auth/register/step1
// Body: { name, lastName, dni, phone, email, password }
// ─────────────────────────────────────────────
export const registerStep1 = async (req: Request, res: Response): Promise<void> => {
  try {
    const { name, lastName, dni, phone, email, password } = req.body;

    if (!name || !lastName || !dni || !phone || !email || !password) {
      res.status(400).json({ message: 'Todos los campos del paso 1 son requeridos.' });
      return;
    }

    if (password.length < 6) {
      res.status(400).json({ message: 'La contraseña debe tener al menos 6 caracteres.' });
      return;
    }

    const existingEmail = await prisma.user.findUnique({ where: { email } });
    if (existingEmail) {
      res.status(409).json({ message: 'Ya existe una cuenta con ese email.' });
      return;
    }

    const existingDni = await prisma.user.findUnique({ where: { dni } });
    if (existingDni) {
      res.status(409).json({ message: 'Ya existe una cuenta con ese DNI.' });
      return;
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = await prisma.user.create({
      data: { name, lastName, dni, phone, email, password: hashedPassword },
    });

    const token = generateToken(user.id);

    res.status(201).json({
      message: 'Paso 1 completado. Continuá con el paso 2.',
      token,
      userId: user.id,
    });
  } catch (error) {
    console.error('registerStep1 error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// POST /auth/register/step2
// Body: { userId, photo?, address, number, country, city, zipCode }
// ─────────────────────────────────────────────
export const registerStep2 = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId, photo, address, number, country, city, zipCode } = req.body;

    if (!userId || !address || !number || !country || !city || !zipCode) {
      res.status(400).json({ message: 'Todos los campos del paso 2 son requeridos.' });
      return;
    }

    const user = await prisma.user.findUnique({ where: { id: Number(userId) } });
    if (!user) {
      res.status(404).json({ message: 'Usuario no encontrado.' });
      return;
    }

    const updatedUser = await prisma.user.update({
      where: { id: Number(userId) },
      data: { photo, address, number, country, city, zipCode },
      select: {
        id: true,
        name: true,
        lastName: true,
        email: true,
        phone: true,
        address: true,
        city: true,
        country: true,
      },
    });

    res.json({
      message: 'Registro completado correctamente.',
      user: updatedUser,
    });
  } catch (error) {
    console.error('registerStep2 error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// POST /auth/login
// Body: { email, password }
// ─────────────────────────────────────────────
export const login = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ message: 'Email y contraseña son requeridos.' });
      return;
    }

    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) {
      res.status(401).json({ message: 'Email o contraseña incorrectos.' });
      return;
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      res.status(401).json({ message: 'Email o contraseña incorrectos.' });
      return;
    }

    const token = generateToken(user.id);

    res.json({
      message: 'Sesión iniciada correctamente.',
      token,
      user: {
        id: user.id,
        name: user.name,
        lastName: user.lastName,
        email: user.email,
        phone: user.phone,
        photo: user.photo,
      },
    });
  } catch (error) {
    console.error('login error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// POST /auth/forgot-password
// Body: { email }
// ─────────────────────────────────────────────
export const forgotPassword = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email } = req.body;

    if (!email) {
      res.status(400).json({ message: 'El email es requerido.' });
      return;
    }

    const user = await prisma.user.findUnique({ where: { email } });

    if (!user) {
      res.json({ message: 'Si el email existe, recibirás un código.' });
      return;
    }

    const code = generateCode();
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000);

    await prisma.passwordResetCode.upsert({
      where: { userId: user.id },
      update: { code, expiresAt, used: false },
      create: { userId: user.id, code, expiresAt },
    });

    await sendResetCodeEmail(email, code);

    res.json({ message: 'Si el email existe, recibirás un código.' });
  } catch (error) {
    console.error('forgotPassword error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// POST /auth/verify-code
// Body: { email, code }
// ─────────────────────────────────────────────
export const verifyCode = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, code } = req.body;

    if (!email || !code) {
      res.status(400).json({ message: 'Email y código son requeridos.' });
      return;
    }

    const user = await prisma.user.findUnique({
      where: { email },
      include: { passwordResetCode: true },
    });

    if (!user || !user.passwordResetCode) {
      res.status(400).json({ message: 'Código inválido o expirado.' });
      return;
    }

    const resetCode = user.passwordResetCode;

    if (resetCode.used) {
      res.status(400).json({ message: 'Este código ya fue utilizado.' });
      return;
    }

    if (new Date() > resetCode.expiresAt) {
      res.status(400).json({ message: 'El código ha expirado. Solicitá uno nuevo.' });
      return;
    }

    if (resetCode.code !== code) {
      res.status(400).json({ message: 'Código incorrecto.' });
      return;
    }

    res.json({ message: 'Código válido. Podés restablecer tu contraseña.' });
  } catch (error) {
    console.error('verifyCode error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// POST /auth/reset-password
// Body: { email, code, newPassword }
// ─────────────────────────────────────────────
export const resetPassword = async (req: Request, res: Response): Promise<void> => {
  try {
    const { email, code, newPassword } = req.body;

    if (!email || !code || !newPassword) {
      res.status(400).json({ message: 'Email, código y nueva contraseña son requeridos.' });
      return;
    }

    if (newPassword.length < 6) {
      res.status(400).json({ message: 'La contraseña debe tener al menos 6 caracteres.' });
      return;
    }

    const user = await prisma.user.findUnique({
      where: { email },
      include: { passwordResetCode: true },
    });

    if (!user || !user.passwordResetCode) {
      res.status(400).json({ message: 'Código inválido o expirado.' });
      return;
    }

    const resetCode = user.passwordResetCode;

    if (resetCode.used || new Date() > resetCode.expiresAt || resetCode.code !== code) {
      res.status(400).json({ message: 'Código inválido o expirado.' });
      return;
    }

    const hashedPassword = await bcrypt.hash(newPassword, 10);

    await prisma.$transaction([
      prisma.user.update({
        where: { id: user.id },
        data: { password: hashedPassword },
      }),
      prisma.passwordResetCode.update({
        where: { userId: user.id },
        data: { used: true },
      }),
    ]);

    res.json({ message: 'Contraseña restablecida correctamente.' });
  } catch (error) {
    console.error('resetPassword error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};
