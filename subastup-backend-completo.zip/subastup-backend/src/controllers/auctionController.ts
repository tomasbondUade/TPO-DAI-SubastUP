import { Request, Response } from 'express';
import prisma from '../lib/prisma';

// ─────────────────────────────────────────────
// GET /auctions
// Devuelve subastas especiales y comunes para el Home
// ─────────────────────────────────────────────
export const getHome = async (_req: Request, res: Response): Promise<void> => {
  try {
    const [special, common] = await Promise.all([
      prisma.auction.findMany({
        where: { type: 'SPECIAL', active: true },
        include: { products: { include: { images: true } } },
        orderBy: { createdAt: 'desc' },
      }),
      prisma.auction.findMany({
        where: { type: 'COMMON', active: true },
        include: { products: { include: { images: true } } },
        orderBy: { createdAt: 'desc' },
      }),
    ]);

    res.json({ special, common });
  } catch (error) {
    console.error('getHome error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// GET /auctions/:id
// Devuelve el detalle de una subasta
// ─────────────────────────────────────────────
export const getAuctionById = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;

    const auction = await prisma.auction.findUnique({
      where: { id: Number(id) },
      include: { products: { include: { images: true } } },
    });

    if (!auction) {
      res.status(404).json({ message: 'Subasta no encontrada.' });
      return;
    }

    res.json(auction);
  } catch (error) {
    console.error('getAuctionById error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};
