import { Request, Response } from 'express';
import prisma from '../lib/prisma';

// ─────────────────────────────────────────────
// GET /bids/calendar?month=9&year=2025
// Devuelve los días del mes que tienen pujas activas
// ─────────────────────────────────────────────
export const getCalendarBids = async (req: Request, res: Response): Promise<void> => {
  try {
    const { month, year } = req.query;

    if (!month || !year) {
      res.status(400).json({ message: 'month y year son requeridos.' });
      return;
    }

    const m = Number(month);
    const y = Number(year);

    const startOfMonth = new Date(y, m - 1, 1);
    const endOfMonth = new Date(y, m, 0, 23, 59, 59);

    // Traemos todas las pujas activas del mes
    const auctions = await prisma.auctionBid.findMany({
      where: {
        status: 'ACTIVE',
        startTime: { lte: endOfMonth },
        endTime: { gte: startOfMonth },
      },
      include: {
        product: { include: { images: true } },
      },
    });

    // Construimos un set de días que tienen pujas
    const daysWithBids = new Set<number>();
    auctions.forEach((bid) => {
      const start = new Date(bid.startTime);
      const end = new Date(bid.endTime);
      // Marcamos cada día dentro del rango de la puja
      const cursor = new Date(start);
      while (cursor <= end) {
        if (cursor.getMonth() + 1 === m && cursor.getFullYear() === y) {
          daysWithBids.add(cursor.getDate());
        }
        cursor.setDate(cursor.getDate() + 1);
      }
    });

    res.json({
      month: m,
      year: y,
      daysWithBids: Array.from(daysWithBids).sort((a, b) => a - b),
    });
  } catch (error) {
    console.error('getCalendarBids error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// GET /bids/day?date=2025-09-09
// Devuelve las pujas activas de un día específico
// ─────────────────────────────────────────────
export const getBidsByDay = async (req: Request, res: Response): Promise<void> => {
  try {
    const { date } = req.query;

    if (!date) {
      res.status(400).json({ message: 'date es requerido (formato: YYYY-MM-DD).' });
      return;
    }

    const selected = new Date(String(date));
    const startOfDay = new Date(selected);
    startOfDay.setHours(0, 0, 0, 0);
    const endOfDay = new Date(selected);
    endOfDay.setHours(23, 59, 59, 999);

    const bids = await prisma.auctionBid.findMany({
      where: {
        status: 'ACTIVE',
        startTime: { lte: endOfDay },
        endTime: { gte: startOfDay },
      },
      include: {
        product: { include: { images: true } },
      },
      orderBy: { endTime: 'asc' },
    });

    res.json(bids);
  } catch (error) {
    console.error('getBidsByDay error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// GET /bids/:id
// Detalle de una puja: imagen, nombre, ID, descripción, tiempo restante
// ─────────────────────────────────────────────
export const getBidDetail = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;

    const bid = await prisma.auctionBid.findUnique({
      where: { id: Number(id) },
      include: {
        product: { include: { images: true } },
        offers: {
          orderBy: { amount: 'desc' },
          take: 1, // oferta más alta actual
        },
      },
    });

    if (!bid) {
      res.status(404).json({ message: 'Puja no encontrada.' });
      return;
    }

    const now = new Date();
    const secondsRemaining = Math.max(
      0,
      Math.floor((bid.endTime.getTime() - now.getTime()) / 1000)
    );
    const totalSeconds = Math.floor(
      (bid.endTime.getTime() - bid.startTime.getTime()) / 1000
    );
    const progressPercent = Math.max(
      0,
      Math.min(100, ((totalSeconds - secondsRemaining) / totalSeconds) * 100)
    );

    res.json({
      ...bid,
      secondsRemaining,
      progressPercent: Math.round(progressPercent),
      currentHighestBid: bid.offers[0]?.amount ?? bid.startingPrice,
    });
  } catch (error) {
    console.error('getBidDetail error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// POST /bids/:id/offer
// El usuario hace una oferta en una puja
// Body: { userId, amount }
// ─────────────────────────────────────────────
export const placeBidOffer = async (req: Request, res: Response): Promise<void> => {
  try {
    const { id } = req.params;
    const { userId, amount } = req.body;

    if (!userId || !amount) {
      res.status(400).json({ message: 'userId y amount son requeridos.' });
      return;
    }

    const bid = await prisma.auctionBid.findUnique({
      where: { id: Number(id) },
      include: {
        offers: { orderBy: { amount: 'desc' }, take: 1 },
      },
    });

    if (!bid) {
      res.status(404).json({ message: 'Puja no encontrada.' });
      return;
    }

    if (bid.status !== 'ACTIVE') {
      res.status(400).json({ message: 'Esta puja no está activa.' });
      return;
    }

    if (new Date() > bid.endTime) {
      res.status(400).json({ message: 'Esta puja ya finalizó.' });
      return;
    }

    const currentHighest = bid.offers[0]?.amount ?? bid.startingPrice;
    if (Number(amount) <= currentHighest) {
      res.status(400).json({
        message: `Tu oferta debe ser mayor a ${currentHighest} ${bid.currency}.`,
      });
      return;
    }

    const offer = await prisma.bidOffer.create({
      data: {
        auctionBidId: Number(id),
        userId: Number(userId),
        amount: Number(amount),
      },
    });

    res.status(201).json({
      message: '¡Oferta realizada con éxito!',
      offer,
      currentHighestBid: offer.amount,
    });
  } catch (error) {
    console.error('placeBidOffer error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};
