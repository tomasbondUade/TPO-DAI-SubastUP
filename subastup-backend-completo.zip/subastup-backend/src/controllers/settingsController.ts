import { Request, Response } from 'express';
import prisma from '../lib/prisma';

// ─────────────────────────────────────────────
// GET /settings/:userId
// Devuelve la configuración del usuario
// ─────────────────────────────────────────────
export const getSettings = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId } = req.params;

    let settings = await prisma.userSettings.findUnique({
      where: { userId: Number(userId) },
    });

    // Si no existe, creamos con valores por defecto
    if (!settings) {
      settings = await prisma.userSettings.create({
        data: { userId: Number(userId) },
      });
    }

    res.json(settings);
  } catch (error) {
    console.error('getSettings error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// PATCH /settings/:userId
// Actualiza configuración del usuario
// Body: { darkMode?, notifications?, currency? }
// ─────────────────────────────────────────────
export const updateSettings = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId } = req.params;
    const { darkMode, notifications, currency } = req.body;

    const settings = await prisma.userSettings.upsert({
      where: { userId: Number(userId) },
      update: {
        ...(darkMode !== undefined && { darkMode }),
        ...(notifications !== undefined && { notifications }),
        ...(currency !== undefined && { currency }),
      },
      create: {
        userId: Number(userId),
        darkMode: darkMode ?? false,
        notifications: notifications ?? true,
        currency: currency ?? 'ARS',
      },
    });

    res.json({ message: 'Configuración actualizada.', settings });
  } catch (error) {
    console.error('updateSettings error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// PATCH /settings/:userId/profile
// Editar perfil del usuario
// Body: { name?, lastName?, phone?, photo?, address?, city?, country?, zipCode? }
// ─────────────────────────────────────────────
export const editProfile = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId } = req.params;
    const { name, lastName, phone, photo, address, city, country, zipCode } = req.body;

    const user = await prisma.user.findUnique({ where: { id: Number(userId) } });
    if (!user) {
      res.status(404).json({ message: 'Usuario no encontrado.' });
      return;
    }

    const updated = await prisma.user.update({
      where: { id: Number(userId) },
      data: {
        ...(name && { name }),
        ...(lastName && { lastName }),
        ...(phone && { phone }),
        ...(photo && { photo }),
        ...(address && { address }),
        ...(city && { city }),
        ...(country && { country }),
        ...(zipCode && { zipCode }),
      },
      select: {
        id: true, name: true, lastName: true,
        email: true, phone: true, photo: true,
        address: true, city: true, country: true, zipCode: true,
      },
    });

    res.json({ message: 'Perfil actualizado correctamente.', user: updated });
  } catch (error) {
    console.error('editProfile error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};
