import { Request, Response } from 'express';
import prisma from '../lib/prisma';
import path from 'path';
import fs from 'fs';

// ─────────────────────────────────────────────
// POST /products/step1
// Crea el producto con los detalles del lote
// Body: { userId, name, category, subcategory, description }
// ─────────────────────────────────────────────
export const createProductStep1 = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId, name, category, subcategory, description } = req.body;

    if (!userId || !name || !description) {
      res.status(400).json({ message: 'userId, nombre y descripción son requeridos.' });
      return;
    }

    const user = await prisma.user.findUnique({ where: { id: Number(userId) } });
    if (!user) {
      res.status(404).json({ message: 'Usuario no encontrado.' });
      return;
    }

    const product = await prisma.product.create({
      data: {
        name,
        category: category || null,
        subcategory: subcategory || null,
        description,
        userId: Number(userId),
      },
    });

    res.status(201).json({
      message: 'Paso 1 completado. Continuá cargando las imágenes.',
      productId: product.id,
    });
  } catch (error) {
    console.error('createProductStep1 error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// POST /products/step2/:productId
// Sube hasta 4 imágenes del producto
// Multipart form-data: files[] (máx 4 imágenes)
// ─────────────────────────────────────────────
export const uploadProductImages = async (req: Request, res: Response): Promise<void> => {
  try {
    const { productId } = req.params;

    const product = await prisma.product.findUnique({
      where: { id: Number(productId) },
      include: { images: true },
    });

    if (!product) {
      res.status(404).json({ message: 'Producto no encontrado.' });
      return;
    }

    const existingCount = product.images.length;
    const files = req.files as Express.Multer.File[];

    if (!files || files.length === 0) {
      res.status(400).json({ message: 'Debés subir al menos una imagen.' });
      return;
    }

    if (existingCount + files.length > 4) {
      res.status(400).json({
        message: `Solo podés subir hasta 4 imágenes. Ya tenés ${existingCount}.`,
      });
      return;
    }

    const imageData = files.map((file, index) => ({
      url: `/uploads/products/${file.filename}`,
      order: existingCount + index,
      productId: Number(productId),
    }));

    await prisma.productImage.createMany({ data: imageData });

    // Marca el producto como finalizado
    await prisma.product.update({
      where: { id: Number(productId) },
      data: { status: 'PENDING' },
    });

    const updatedProduct = await prisma.product.findUnique({
      where: { id: Number(productId) },
      include: { images: true },
    });

    res.json({
      message: 'Guardado y finalizado. Tu producto fue enviado para revisión.',
      product: updatedProduct,
    });
  } catch (error) {
    console.error('uploadProductImages error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};

// ─────────────────────────────────────────────
// GET /products/user/:userId
// Devuelve todos los productos de un usuario
// ─────────────────────────────────────────────
export const getProductsByUser = async (req: Request, res: Response): Promise<void> => {
  try {
    const { userId } = req.params;

    const products = await prisma.product.findMany({
      where: { userId: Number(userId) },
      include: { images: true },
      orderBy: { createdAt: 'desc' },
    });

    res.json(products);
  } catch (error) {
    console.error('getProductsByUser error:', error);
    res.status(500).json({ message: 'Error interno del servidor.' });
  }
};
