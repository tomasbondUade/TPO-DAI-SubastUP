import { Router } from 'express';
import { getSettings, updateSettings, editProfile } from '../controllers/settingsController';

const router = Router();

router.get('/:userId', getSettings);
router.patch('/:userId', updateSettings);
router.patch('/:userId/profile', editProfile);

export default router;
