import { Router } from 'express';
import { createProductStep1, uploadProductImages, getProductsByUser } from '../controllers/productController';
import { uploadImages } from '../middlewares/uploadMiddleware';

const router = Router();

router.post('/step1', createProductStep1);
router.post('/step2/:productId', uploadImages, uploadProductImages);
router.get('/user/:userId', getProductsByUser);

export default router;
