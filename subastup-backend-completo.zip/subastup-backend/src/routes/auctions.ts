import { Router } from 'express';
import { getHome, getAuctionById } from '../controllers/auctionController';

const router = Router();

router.get('/', getHome);
router.get('/:id', getAuctionById);

export default router;
