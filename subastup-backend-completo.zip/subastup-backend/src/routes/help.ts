import { Router } from 'express';
import { getHelp } from '../controllers/helpController';

const router = Router();

router.get('/', getHelp);

export default router;
