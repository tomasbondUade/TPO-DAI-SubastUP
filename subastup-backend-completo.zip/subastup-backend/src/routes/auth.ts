import { Router } from 'express';
import {
  registerStep1,
  registerStep2,
  login,
  forgotPassword,
  verifyCode,
  resetPassword,
} from '../controllers/authController';

const router = Router();

// Registro en 2 pasos
router.post('/register/step1', registerStep1);
router.post('/register/step2', registerStep2);

// Login
router.post('/login', login);

// Recuperar contraseña
router.post('/forgot-password', forgotPassword);
router.post('/verify-code', verifyCode);
router.post('/reset-password', resetPassword);

export default router;
