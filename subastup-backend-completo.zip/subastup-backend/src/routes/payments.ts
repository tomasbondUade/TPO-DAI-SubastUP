import { Router } from 'express';
import {
  getPaymentMethods,
  addCardPayment,
  addBankPayment,
  addCheckPayment,
  deletePaymentMethod,
} from '../controllers/paymentController';
import { uploadCheckImage } from '../middlewares/uploadMiddleware';

const router = Router();

router.get('/:userId', getPaymentMethods);
router.post('/card', addCardPayment);
router.post('/bank', addBankPayment);
router.post('/check', uploadCheckImage, addCheckPayment);
router.delete('/:id', deletePaymentMethod);

export default router;
