import { Router } from 'express';
import {
  getCalendarBids,
  getBidsByDay,
  getBidDetail,
  placeBidOffer,
} from '../controllers/bidController';

const router = Router();

// Calendario
router.get('/calendar', getCalendarBids);   // ?month=9&year=2025
router.get('/day', getBidsByDay);           // ?date=2025-09-09

// Detalle y ofertar
router.get('/:id', getBidDetail);
router.post('/:id/offer', placeBidOffer);

export default router;
