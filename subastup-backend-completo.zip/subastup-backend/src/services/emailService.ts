import nodemailer from 'nodemailer';

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.GMAIL_USER,
    pass: process.env.GMAIL_PASS,
  },
});

export const sendResetCodeEmail = async (to: string, code: string): Promise<void> => {
  await transporter.sendMail({
    from: `"SubastUp" <${process.env.GMAIL_USER}>`,
    to,
    subject: 'Código para restablecer tu contraseña',
    html: `
      <div style="font-family: Arial, sans-serif; max-width: 480px; margin: 0 auto;">
        <h2 style="color: #C0392B;">SubastUp</h2>
        <p>Recibimos una solicitud para restablecer tu contraseña.</p>
        <p>Tu código de verificación es:</p>
        <div style="
          font-size: 36px;
          font-weight: bold;
          letter-spacing: 8px;
          color: #C0392B;
          text-align: center;
          padding: 20px;
          background: #fdecea;
          border-radius: 8px;
          margin: 20px 0;
        ">
          ${code}
        </div>
        <p>Este código expira en <strong>15 minutos</strong>.</p>
        <p>Si no solicitaste esto, podés ignorar este email.</p>
      </div>
    `,
  });
};
