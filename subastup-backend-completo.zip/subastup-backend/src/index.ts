import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'path';

import authRoutes from './routes/auth';
import auctionRoutes from './routes/auctions';
import productRoutes from './routes/products';
import helpRoutes from './routes/help';
import paymentRoutes from './routes/payments';
import settingsRoutes from './routes/settings';
import bidRoutes from './routes/bids';

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

// Archivos estáticos
app.use('/uploads', express.static(path.join(process.cwd(), 'uploads')));

// Rutas
app.use('/auth', authRoutes);
app.use('/auctions', auctionRoutes);
app.use('/products', productRoutes);
app.use('/help', helpRoutes);
app.use('/payments', paymentRoutes);
app.use('/settings', settingsRoutes);
app.use('/bids', bidRoutes);

// Health check
app.get('/health', (_req, res) => {
  res.json({ status: 'ok', app: 'SubastUp API' });
});

app.listen(PORT, () => {
  console.log(`🚀 Servidor corriendo en http://localhost:${PORT}`);
});
